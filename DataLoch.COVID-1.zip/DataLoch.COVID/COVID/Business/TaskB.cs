﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System.Data;
using System.Data.Common;
using COVID.Entities;

namespace COVID.Business
{
    /// <summary>
    /// Provides methods to manage Tasks.
    /// </summary>
    public class TaskB
    {        
        /// <summary>
        /// Constructor.
        /// </summary>
        public TaskB()
        {            
        }

        /// <summary>
        /// Returns the next outstanding task. 
        /// </summary>        
        /// <returns>Next outstanding task.</returns>
        public COVID.Entities.Task GetNextTask()
        {
            COVID.Entities.Task task = null;

            DateTime currentDateTime = DateTime.Now;
            Database databaseObject = DatabaseFactory.CreateDatabase();

            string sql = "Select ";
            sql += "tsk.TaskId, ";
            sql += "tsk.TaskDesc ";
            sql += "From [COVID].[Task] tsk ";
            sql += "Where tsk.ScheduledDateTime <= @CurrentDateTime ";
            sql += "And tsk.StartDateTime Is Null ";
            sql += "And tsk.TaskDesc In ('iLab COVID Refresh', 'Generate Questionnaires', 'Load Questionnaires') ";
            sql += "Order By tsk.ScheduledDateTime Asc";
         
            using (DbCommand cmd = databaseObject.GetSqlStringCommand(sql))
            {                
                databaseObject.AddInParameter(cmd, "CurrentDateTime", DbType.DateTime, currentDateTime);

                using (IDataReader dataReader = databaseObject.ExecuteReader(cmd))
                {
                    if (dataReader.Read())
                    {
                        task = new Entities.Task();
                        task.TaskId = Helper.GetPropertyValueInt(dataReader, "TaskId");
                        task.TaskDesc = Helper.GetPropertyValueString(dataReader, "TaskDesc");
                    }
                }
            }

            return task;
        }

        /// <summary>
        /// Returns the next outstanding task with the given description. 
        /// </summary>
        /// <param name="aTaskDescription">Task description.</param>
        /// <returns>Next outstanding task.</returns>
        public int? GetNextTask(string aTaskDescription)
        {
            int? taskId = null;

            DateTime currentDateTime = DateTime.Now;
            Database databaseObject = DatabaseFactory.CreateDatabase();

            string sql = "Select ";
            sql += "tsk.TaskId ";
            sql += "From [COVID].[Task] tsk ";
            sql += "Where tsk.TaskDesc = @TaskDesc ";
            sql += "And tsk.ScheduledDateTime <= @CurrentDateTime ";
            sql += "And tsk.StartDateTime Is Null ";
            sql += "Order By tsk.ScheduledDateTime Asc";

            using (DbCommand cmd = databaseObject.GetSqlStringCommand(sql))
            {
                databaseObject.AddInParameter(cmd, "TaskDesc", DbType.String, aTaskDescription);
                databaseObject.AddInParameter(cmd, "CurrentDateTime", DbType.DateTime, currentDateTime);

                using (IDataReader dataReader = databaseObject.ExecuteReader(cmd))
                {
                    if (dataReader.Read())
                    {
                        taskId = Helper.GetPropertyValueInt(dataReader, "TaskId");
                    }
                }
            }

            return taskId;
        }

        /// <summary>
        /// Starts the given task. 
        /// </summary>
        /// <param name="aTaskId">Task Id.</param>
        /// <returns>Indication of success.</returns>
        public bool StartTask(int? aTaskId)
        {
            bool success = false;

            DateTime currentDateTime = DateTime.Now;
            Database databaseObject = DatabaseFactory.CreateDatabase();

            string sql = "Update [COVID].[Task] ";
            sql += "Set StartDateTime = @CurrentDateTime ";
            sql += "Where TaskId = @TaskId ";
            sql += "And StartDateTime Is Null";

            using (DbCommand cmd = databaseObject.GetSqlStringCommand(sql))
            {
                databaseObject.AddInParameter(cmd, "CurrentDateTime", DbType.DateTime, currentDateTime);
                databaseObject.AddInParameter(cmd, "TaskId", DbType.Int32, aTaskId);

                int rowsAffected = databaseObject.ExecuteNonQuery(cmd);
                success = rowsAffected > 0;
            }

            return success;
        }

        /// <summary>
        /// Completes the given task. 
        /// </summary>
        /// <param name="aTaskId">Task Id.</param>
        /// <param name="aCompletionStatus">Completion Status.</param>
        /// <returns>Indication of success.</returns>
        public bool CompleteTask(int? aTaskId, string aCompletionStatus)
        {
            bool success = false;

            DateTime currentDateTime = DateTime.Now;
            Database databaseObject = DatabaseFactory.CreateDatabase();

            string sql = "Update [COVID].[Task] ";
            sql += "Set CompleteDateTime = @CurrentDateTime, ";
            sql += "CompletionStatus = @CompletionStatus ";
            sql += "Where TaskId = @TaskId ";

            using (DbCommand cmd = databaseObject.GetSqlStringCommand(sql))
            {
                databaseObject.AddInParameter(cmd, "CurrentDateTime", DbType.DateTime, currentDateTime);
                databaseObject.AddInParameter(cmd, "CompletionStatus", DbType.String, aCompletionStatus);
                databaseObject.AddInParameter(cmd, "TaskId", DbType.Int32, aTaskId);

                int rowsAffected = databaseObject.ExecuteNonQuery(cmd);
                success = rowsAffected > 0;
            }

            return success;
        }               
    }
}
