﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System.Data;
using System.Data.Common;
using System.Runtime.InteropServices;
using Microsoft.Office.Interop.Excel;
using COVID.Entities;

namespace COVID.Business
{
    /// <summary>
    /// Provides methods to create blank Questionnaire spreadsheets, and to extract and load data from populated Questionnaire spreadsheets.
    /// </summary>
    public class QuestionnaireB
    {
        private Dictionary<Type, DbType> _typeMap;

        /// <summary>
        /// Constructor.
        /// </summary>
        public QuestionnaireB()
        {
            _typeMap = Helper.GetTypeMap();
        }

        /// <summary>
        /// Generates a Questionnaire (excel spreadsheet) for each COVID positive patient. Note that a Questionnaire
        /// is only issued once per patient.
        /// </summary>
        /// <param name="taskSummaryDetails">Task summary details.</param>
        /// <returns>Indication of success.</returns>
        public bool GenerateQuestionnaires(out string taskSummaryDetails)
        {
            bool success = false;
            taskSummaryDetails = string.Empty;

            string generatedQuestionnaireFolder = ConfigurationManager.AppSettings["GeneratedQuestionnaireFolder"];

            if (!Directory.Exists(generatedQuestionnaireFolder))
            {
                taskSummaryDetails = string.Format("Generated Questionnaire Folder '{0}' does not exist.", generatedQuestionnaireFolder);
                return success;
            }

            string templateQuestionnaireFilePath = ConfigurationManager.AppSettings["TemplateQuestionnaireFilePath"];

            if (!File.Exists(templateQuestionnaireFilePath))
            {
                taskSummaryDetails = string.Format("Template Questionnaire File '{0}' does not exist.", templateQuestionnaireFilePath);
                return success;
            }
            
            // create new sub-folder to save generated questionnaires to, so that previously generated questionnaires are not over-written
            //
            string newFolderName = DateTime.Now.ToString("yyyyMMddHHmmss");
            generatedQuestionnaireFolder = Path.Combine(generatedQuestionnaireFolder, newFolderName);
            Directory.CreateDirectory(generatedQuestionnaireFolder);           

            Application xlApp = new Application();

            try
            {
                int processedCount = 0;
                int successCount = 0;
                int failureCount = 0;
                DateTime? issuedDateTime = DateTime.Now;

                // retrieve details of all COVID positive patients
                //
                Database databaseObject = DatabaseFactory.CreateDatabase();                
                System.Data.DataTable dtIssuedQuestionnaire = GetDataTableIssuedQuestionnaire(databaseObject);                

                string storedProcedureName = "[DataLoch].[GetQuestionnaireCohort]";

                using (DbCommand cmd = databaseObject.GetStoredProcCommand(storedProcedureName))
                {                                 
                    using (IDataReader dataReader = databaseObject.ExecuteReader(cmd))
                    {
                        while (dataReader.Read())
                        {
                            Demographics demographics = new Demographics();
                            demographics.CHI = Helper.GetPropertyValueString(dataReader, "chi");
                            demographics.UHPI = Helper.GetPropertyValueString(dataReader, "uhpi");
                            demographics.DateOfBirth = Helper.GetPropertyValueDateTime(dataReader, "dateOfBirth");                            
                            demographics.Sex = Helper.GetPropertyValueString(dataReader, "sex");
                            demographics.EpisodeStart = Helper.GetPropertyValueDateTime(dataReader, "episodeStart");
                            demographics.EpisodeEnd = Helper.GetPropertyValueDateTime(dataReader, "episodeEnd");

                            string errorMessage;
                            bool questionnaireGenerated = GenerateQuestionnaire(xlApp, demographics, templateQuestionnaireFilePath, generatedQuestionnaireFolder, out errorMessage);

                            if (questionnaireGenerated)
                            {
                                // flag the patient as having had a Questionnaire issued (only wish to issue one per patient episode)
                                QuestionnaireIssued(databaseObject, demographics, issuedDateTime, dtIssuedQuestionnaire);
                                successCount++;
                            }
                            else
                            {
                                taskSummaryDetails += Environment.NewLine;
                                taskSummaryDetails += "Questionnaire Generation Failure" + Environment.NewLine;
                                taskSummaryDetails += "CHI: " + demographics.CHI + Environment.NewLine;
                                taskSummaryDetails += "UHPI: " + demographics.UHPI + Environment.NewLine;

                                string episodeStart = string.Empty;
                                if (demographics.EpisodeStart.HasValue)
                                {
                                    episodeStart = demographics.EpisodeStart.Value.ToString("dd-MMM-yyyy HH:mm");
                                }

                                taskSummaryDetails += "Episode Start: " + episodeStart + Environment.NewLine;
                                taskSummaryDetails += "Error Message: " + errorMessage + Environment.NewLine;
                                taskSummaryDetails += Environment.NewLine;

                                failureCount++;
                            }

                            processedCount++;
                        }
                    }
                }

                string summaryDetails = string.Format("Generated Questionnaire Folder: '{0}'", generatedQuestionnaireFolder) + Environment.NewLine;
                summaryDetails += string.Format("Questionnaires Successfully Generated: '{0}'", successCount) + Environment.NewLine;
                summaryDetails += string.Format("Questionnaire Generation Failures: '{0}'", failureCount) + Environment.NewLine;

                taskSummaryDetails = summaryDetails + taskSummaryDetails;               

                success = true;
            }
            finally
            {
                xlApp.Quit();
                Marshal.ReleaseComObject(xlApp);
            }

            return success;
        }

        /// <summary>
        /// Adds patient episode to list of patient episodes that have had a Questionnaire issued.
        /// </summary>
        /// <param name="database"></param>
        /// <param name="demographics">Patient episode details.</param>
        /// <param name="issuedDateTime">Date and Time that Questionnaire issued.</param>
        /// <param name="dtIssuedQuestionnaire">IssuedQuestionnaire DataTable.</param>
        private void QuestionnaireIssued(Database database, Demographics demographics, DateTime? issuedDateTime, System.Data.DataTable dtIssuedQuestionnaire)
        {
            DataRow drIssuedQuestionnaire = dtIssuedQuestionnaire.NewRow();           

            Helper.SetPropertyValueDateTime(drIssuedQuestionnaire, "IssuedDateTime", issuedDateTime); 
            Helper.SetPropertyValueString(drIssuedQuestionnaire, "CHI", demographics.CHI);            
            Helper.SetPropertyValueString(drIssuedQuestionnaire, "UHPI", demographics.UHPI);
            Helper.SetPropertyValueDateTime(drIssuedQuestionnaire, "EpisodeStart", demographics.EpisodeStart);

            List<string> excludedColumnList = new List<string>();
            excludedColumnList.Add("IssuedQuestionnaireId");
            Insert(database, "COVID", "IssuedQuestionnaire", drIssuedQuestionnaire, excludedColumnList);
        }
      
        /// <summary>
        /// Generates a questionnaire for a COVID positive patient.
        /// </summary>
        /// <param name="xlApp"></param>
        /// <param name="demographics">Patient details.</param>
        /// <param name="templatePath">Template questionnaire file path.</param>
        /// <param name="targetFolder">Target folder to save generated questionnaire to.</param>
        /// <param name="errorMessage">Error message.</param>
        /// <returns>Indication of success.</returns>
        private bool GenerateQuestionnaire(Application xlApp, Demographics demographics, string templatePath,
                                    string targetFolder, out string errorMessage)
        {
            bool success = true;
            errorMessage = string.Empty;

            Range currCell = null;
            Range cells = null;
            Workbooks workbooks = null;
            Workbook wbQuestionnaire = null;
            Sheets worksheets = null;
            Worksheet wsQuestionnaire = null;

            try
            {
                string fileName;

                string episodeStart = string.Empty;
                if (demographics.EpisodeStart.HasValue)
                {
                    episodeStart = demographics.EpisodeStart.Value.ToString("ddMMMyyyy_HHmm");
                }

                if (!string.IsNullOrEmpty(demographics.CHI))
                {
                    fileName = string.Format("{0}_{1}.xlsx", demographics.CHI, episodeStart);
                }
                else
                {
                    fileName = string.Format("{0}_{1}.xlsx", demographics.UHPI, episodeStart);
                }
                
                string questionnaireFilePath = Path.Combine(targetFolder, fileName);
                File.Copy(templatePath, questionnaireFilePath);

                workbooks = xlApp.Workbooks;
                wbQuestionnaire = workbooks.Open(questionnaireFilePath, Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                                       Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                                       Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                worksheets = wbQuestionnaire.Worksheets;
                wsQuestionnaire = (Worksheet)worksheets[1];               
                
                // [CHI] G6
                // [UHPI] G7
                // [DOB] G8
                // [Sex] G9
                // [EpisodeStart] G10
                // [EpisodeEnd] G11                

                int columnNumber = 7; // 7 = G                
                
                cells = wsQuestionnaire.Cells;
               
                int rowNumber = 6;
                currCell = (Range)cells[rowNumber, columnNumber];
                currCell.Value2 = demographics.CHI;                
                Marshal.ReleaseComObject(currCell);

                rowNumber = 7;
                currCell = (Range)cells[rowNumber, columnNumber];
                currCell.Value2 = demographics.UHPI;
                Marshal.ReleaseComObject(currCell);

                rowNumber = 8;
                currCell = (Range)cells[rowNumber, columnNumber];

                string dateOfBirth = string.Empty;
                if (demographics.DateOfBirth.HasValue)
                {
                    dateOfBirth = demographics.DateOfBirth.Value.ToString("dd-MMM-yyyy");
                }

                currCell.Value2 = dateOfBirth;
                Marshal.ReleaseComObject(currCell);

                rowNumber = 9;
                currCell = (Range)cells[rowNumber, columnNumber];
                currCell.Value2 = demographics.Sex;
                Marshal.ReleaseComObject(currCell);

                rowNumber = 10;
                currCell = (Range)cells[rowNumber, columnNumber];

                if (demographics.EpisodeStart.HasValue)
                {
                    episodeStart = demographics.EpisodeStart.Value.ToString("dd-MMM-yyyy HH:mm");
                }

                currCell.Value2 = episodeStart;
                Marshal.ReleaseComObject(currCell);

                rowNumber = 11;
                currCell = (Range)cells[rowNumber, columnNumber];

                string episodeEnd = string.Empty;
                if (demographics.EpisodeEnd.HasValue)
                {
                    episodeEnd = demographics.EpisodeEnd.Value.ToString("dd-MMM-yyyy HH:mm");
                }

                currCell.Value2 = episodeEnd;
                Marshal.ReleaseComObject(currCell);

                wbQuestionnaire.Save();
            }
            catch (Exception ex)
            {
                Console.WriteLine(string.Format("Failed to generate questionnaire for patient '{0}'.", demographics.CHI));
                Console.WriteLine(string.Format("Error message: '{0}'.", ex.ToString()));
                errorMessage = ex.Message;
                success = false;
            }
            finally
            {
                if (currCell != null)
                {
                    Marshal.ReleaseComObject(currCell);
                }

                if (cells != null)
                {
                    Marshal.ReleaseComObject(cells);
                }

                if (wsQuestionnaire != null)
                {
                    Marshal.ReleaseComObject(wsQuestionnaire);
                }

                if (worksheets != null)
                {
                    Marshal.ReleaseComObject(worksheets);
                }

                if (wbQuestionnaire != null)
                {
                    // close the workbook without saving changes
                    wbQuestionnaire.Close(false, Type.Missing, Type.Missing);
                    Marshal.ReleaseComObject(wbQuestionnaire);
                }

                if (workbooks != null)
                {
                    workbooks.Close();
                    Marshal.ReleaseComObject(workbooks);
                }
            }

            return success;
        }
        
        /// <summary>
        /// Loads data from completed questionnaires into the database.
        /// </summary>
        /// <param name="taskSummaryDetails">Task summary details.</param>
        /// <returns>Indication of success.</returns>
        public bool LoadCompletedQuestionnaires(out string taskSummaryDetails)
        {
            bool success = false;
            taskSummaryDetails = string.Empty;

            string completedQuestionnaireFolder = ConfigurationManager.AppSettings["CompletedQuestionnaireFolder"];

            if (!Directory.Exists(completedQuestionnaireFolder))
            {
                taskSummaryDetails = string.Format("Completed Questionnaire Folder '{0}' does not exist.", completedQuestionnaireFolder);                
                return success;
            }
                       
            string[] filePathList = Directory.GetFiles(completedQuestionnaireFolder, "*.xlsx");

            if (filePathList.Length == 0)
            {
                taskSummaryDetails = string.Format("Completed Questionnaire Folder '{0}' does not contain any Questionnaire (xlsx) files.", completedQuestionnaireFolder);                
                return success;
            }

            Application xlApp = new Application();

            try
            {
                int processedCount = 0;
                int successCount = 0;
                int failureCount = 0;

                Database databaseObject = DatabaseFactory.CreateDatabase();
                System.Data.DataTable dtQuestionnaire = GetDataTableQuestionnaire(databaseObject);
                System.Data.DataTable dtQuestionnaireData = GetDataTableQuestionnaireData(databaseObject);                

                for (int fileIndex = 0; fileIndex < filePathList.Length; fileIndex++)
                {
                    string questionnaireFilePath = filePathList[fileIndex];
                    string errorMessage;                    
                    bool questionnaireLoaded = LoadQuestionnaire(xlApp, databaseObject, dtQuestionnaire, dtQuestionnaireData, questionnaireFilePath, out errorMessage);

                    if (questionnaireLoaded)
                    {
                        successCount++;
                    }
                    else
                    {
                        taskSummaryDetails += Environment.NewLine;
                        taskSummaryDetails += "Questionnaire Load Failure" + Environment.NewLine;
                        taskSummaryDetails += "File Name: " + Path.GetFileName(questionnaireFilePath) + Environment.NewLine;
                        taskSummaryDetails += "Error Message: " + errorMessage + Environment.NewLine;
                        taskSummaryDetails += Environment.NewLine;

                        failureCount++;
                    }                    

                    processedCount++;
                }

                string summaryDetails = string.Format("Completed Questionnaire Folder: '{0}'", completedQuestionnaireFolder) + Environment.NewLine;
                summaryDetails += string.Format("Questionnaires Successfully Loaded: '{0}'", successCount) + Environment.NewLine;
                summaryDetails += string.Format("Questionnaire Load Failures: '{0}'", failureCount) + Environment.NewLine;

                taskSummaryDetails = summaryDetails + taskSummaryDetails;

                success = true;
            }            
            finally
            {
                xlApp.Quit();
                Marshal.ReleaseComObject(xlApp);
            }                             

            return success;            
        }        

        /// <summary>
        /// Extracts questionnaire data from an excel workbook and loads the data into the database.
        /// </summary>
        /// <param name="xlApp">Excel Application object.</param>
        /// <param name="database">Database object.</param>
        /// <param name="dtQuestionnaire">Questionnaire DataTable.</param>
        /// <param name="dtQuestionnaireData">QuestionnaireData DataTable.</param>
        /// <param name="questionnaireFilePath">Path of questionnaire file (excel workbook).</param>
        /// <param name="errorMessage">Error message.</param>
        /// <returns>Indication of success.</returns>
        private bool LoadQuestionnaire(Application xlApp, Database database, System.Data.DataTable dtQuestionnaire,
            System.Data.DataTable dtQuestionnaireData, string questionnaireFilePath, out string errorMessage)
        {
            bool success = true;
            errorMessage = string.Empty;

            Range currCell = null;
            Range cells = null;
            Workbooks workbooks = null;
            Workbook wbQuestionnaire = null;
            Sheets worksheets = null;
            Worksheet wsQuestionnaire = null;

            try
            {
                workbooks = xlApp.Workbooks;
                wbQuestionnaire = workbooks.Open(questionnaireFilePath, Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                                       Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                                       Type.Missing, Type.Missing, Type.Missing, Type.Missing);               
                worksheets = wbQuestionnaire.Worksheets;
                wsQuestionnaire = (Worksheet)worksheets[1];                               
                
                DataRow drQuestionnaire = dtQuestionnaire.NewRow();

                Helper.SetPropertyValueString(drQuestionnaire, "FileName", Path.GetFileName(questionnaireFilePath));

                // [DateOfDataExtraction] G3
                // [PersonCompleting] G4                
                // [CHI] G6
                // [UHPI] G7
                // [DOB] G8
                // [Sex] G9
                // [EpisodeStart] G10
                // [EpisodeEnd] G11  

                int columnNumber = 7; // 7 = G                

                int rowNumber = 3;
                cells = wsQuestionnaire.Cells;

                currCell = (Range)cells[rowNumber, columnNumber];
                Helper.SetPropertyValueDateTime(drQuestionnaire, "DateOfDataExtraction", currCell);
                Marshal.ReleaseComObject(currCell);
                
                rowNumber = 4;
                currCell = (Range)cells[rowNumber, columnNumber];
                Helper.SetPropertyValueString(drQuestionnaire, "PersonCompleting", currCell);
                Marshal.ReleaseComObject(currCell);

                rowNumber = 6;
                currCell = (Range)cells[rowNumber, columnNumber];
                Helper.SetPropertyValueString(drQuestionnaire, "CHI", currCell);
                Marshal.ReleaseComObject(currCell);

                rowNumber = 7;
                currCell = (Range)cells[rowNumber, columnNumber];
                Helper.SetPropertyValueString(drQuestionnaire, "UHPI", currCell);
                Marshal.ReleaseComObject(currCell);

                rowNumber = 8;
                currCell = (Range)cells[rowNumber, columnNumber];
                Helper.SetPropertyValueDateTime(drQuestionnaire, "DOB", currCell);
                Marshal.ReleaseComObject(currCell);

                rowNumber = 9;
                currCell = (Range)cells[rowNumber, columnNumber];
                Helper.SetPropertyValueString(drQuestionnaire, "Sex", currCell);
                Marshal.ReleaseComObject(currCell);

                rowNumber = 10;
                currCell = (Range)cells[rowNumber, columnNumber];
                Helper.SetPropertyValueDateTime(drQuestionnaire, "EpisodeStart", currCell);
                Marshal.ReleaseComObject(currCell);

                rowNumber = 11;
                currCell = (Range)cells[rowNumber, columnNumber];
                Helper.SetPropertyValueDateTime(drQuestionnaire, "EpisodeEnd", currCell);
                Marshal.ReleaseComObject(currCell);                

                List<string> excludedColumnList = new List<string>();
                excludedColumnList.Add("QuestionnaireId");
                int questionnaireId = Insert(database, "COVID", "Questionnaire", drQuestionnaire, excludedColumnList);

                List<string> excludedColumnListData = new List<string>();
                excludedColumnListData.Add("QuestionnaireDataId");
                
                // start row for answers = 16               
                rowNumber = 16;
                string currentDomain = string.Empty;
                bool moreQuestions = true;
                int blankRows = 0;
                
                while (moreQuestions)
                {
                    string domain;
                    string variable;
                    string answer;
                    string notRecorded;

                    GetQuestionAndAnswer(wsQuestionnaire, rowNumber, out domain, out variable, out answer, out notRecorded);

                    if (string.IsNullOrEmpty(domain))
                    {
                        domain = currentDomain;
                    }
                    else
                    {
                        currentDomain = domain;
                    }

                    if (string.IsNullOrEmpty(variable))
                    {
                        blankRows++;
                    }
                    else
                    {
                        blankRows = 0;
                    }

                    if (!string.IsNullOrEmpty(domain) &&
                        !string.IsNullOrEmpty(variable))
                    {
                        DataRow drQuestionnaireData = dtQuestionnaireData.NewRow();

                        Helper.SetPropertyValueInt(drQuestionnaireData, "QuestionnaireId", questionnaireId);
                        Helper.SetPropertyValueString(drQuestionnaireData, "Domain", domain);
                        Helper.SetPropertyValueString(drQuestionnaireData, "Variable", variable);
                        Helper.SetPropertyValueString(drQuestionnaireData, "Answer", answer);
                        Helper.SetPropertyValueString(drQuestionnaireData, "NotRecorded", notRecorded);

                        Insert(database, "COVID", "QuestionnaireData", drQuestionnaireData, excludedColumnListData);
                    }

                    if (blankRows > 1)
                    {
                        // more than 1 blank row after another, no more questions
                        moreQuestions = false;
                    }

                    rowNumber++;
                }                
            }
            catch (Exception ex)
            {
                Console.WriteLine(string.Format("Failed to process file '{0}'.", questionnaireFilePath));
                Console.WriteLine(string.Format("Error message: '{0}'.", ex.ToString()));
                errorMessage = ex.Message;
                success = false;
            }
            finally
            {
                if (currCell != null)
                {
                    Marshal.ReleaseComObject(currCell);
                }

                if (cells != null)
                {
                    Marshal.ReleaseComObject(cells);
                }

                if (wsQuestionnaire != null)
                {
                    Marshal.ReleaseComObject(wsQuestionnaire);
                }

                if (worksheets != null)
                {
                    Marshal.ReleaseComObject(worksheets);
                }
               
                if (wbQuestionnaire != null)
                {
                    // close the workbook without saving changes
                    wbQuestionnaire.Close(false, Type.Missing, Type.Missing);
                    Marshal.ReleaseComObject(wbQuestionnaire);
                }

                if (workbooks != null)
                {
                    workbooks.Close();
                    Marshal.ReleaseComObject(workbooks);
                }
            }

            return success;
        }

        /// <summary>
        /// Extracts Domain, Variable, Answer and NotRecorded from the given row in the Questionnaire worksheet.
        /// </summary>
        /// <param name="wsQuestionnaire">Questionnaire worksheet.</param>
        /// <param name="rowNumber">Row number in Questionnaire worksheet.</param>
        /// <param name="domain">Domain.</param>
        /// <param name="variable">Variable.</param>
        /// <param name="answer">Answer.</param>
        /// <param name="notRecorded">Not Recorded.</param>
        private void GetQuestionAndAnswer(Worksheet wsQuestionnaire, int rowNumber, out string domain, out string variable, out string answer, out string notRecorded)
        {
            // column for domain = C = 3
            // column for variable = D = 4
            // column for answer = G = 7
            // column for not recorded = H = 8

            Range currCell = null;
            Range cells = null;

            try
            {
                domain = string.Empty;
                variable = string.Empty;
                answer = string.Empty;
                notRecorded = string.Empty;

                cells = wsQuestionnaire.Cells;

                int columnNumber = 3;
                currCell = cells[rowNumber, columnNumber];
                if (currCell.Value2 != null)
                {
                    domain = currCell.Value2.ToString();
                }
                Marshal.ReleaseComObject(currCell);

                columnNumber = 4;
                currCell = cells[rowNumber, columnNumber];
                if (currCell.Value2 != null)
                {
                    variable = currCell.Value2.ToString();
                }
                Marshal.ReleaseComObject(currCell);

                columnNumber = 7;
                currCell = cells[rowNumber, columnNumber];
                if (currCell.Value2 != null)
                {
                    answer = currCell.Value2.ToString();
                }
                Marshal.ReleaseComObject(currCell);

                columnNumber = 8;
                currCell = cells[rowNumber, columnNumber];
                if (currCell.Value2 != null)
                {
                    notRecorded = currCell.Value2.ToString();
                }
                Marshal.ReleaseComObject(currCell);
            }
            finally
            {
                if (currCell != null)
                {
                    Marshal.ReleaseComObject(currCell);
                }

                if (cells != null)
                {
                    Marshal.ReleaseComObject(cells);
                }
            }
        }

        /// <summary>
        /// Inserts a new record into the target table.
        /// </summary>
        /// <param name="databaseObject">Database object.</param>
        /// <param name="schemaName">Schema name.</param>
        /// <param name="tableName">Table name.</param>
        /// <param name="dataRow">Details of new record to be inserted.</param>
        /// <param name="excludedColumnList">List of excluded column names.</param>        
        /// <returns>Id of newly created record.</returns>
        private int Insert(Database databaseObject, string schemaName, string tableName, DataRow dataRow, List<string> excludedColumnList)
        {
            string sql = "Insert Into [" + schemaName + "].[" + tableName + "] (";

            string columnList = string.Empty;
            string parameterList = string.Empty;

            for (int columnIndex = 0; columnIndex < dataRow.Table.Columns.Count; columnIndex++)
            {
                DataColumn column = dataRow.Table.Columns[columnIndex];

                if (!excludedColumnList.Contains(column.ColumnName))
                {
                    if (columnList != string.Empty)
                    {
                        columnList += ", ";
                    }

                    columnList += column.ColumnName;

                    if (parameterList != string.Empty)
                    {
                        parameterList += ", ";
                    }

                    parameterList += "@" + column.ColumnName;
                }
            }

            sql += columnList + ") Values (" + parameterList + ")";
            sql += ";Select SCOPE_IDENTITY();";

            using (DbCommand insertCommand = databaseObject.GetSqlStringCommand(sql))
            {
                for (int columnIndex = 0; columnIndex < dataRow.Table.Columns.Count; columnIndex++)
                {
                    DataColumn column = dataRow.Table.Columns[columnIndex];

                    if (!excludedColumnList.Contains(column.ColumnName))
                    {
                        databaseObject.AddInParameter(insertCommand, column.ColumnName, _typeMap[column.DataType], dataRow[column.ColumnName]);
                    }
                }

                return (int)(decimal)databaseObject.ExecuteScalar(insertCommand);
            }
        }

        /// <summary>
        /// Returns a Questionnaire DataTable, generated from the database table definition.
        /// </summary>
        /// <param name="databaseObject">Database object.</param>
        /// <returns>Questionnaire DataTable.</returns>
        private System.Data.DataTable GetDataTableQuestionnaire(Database databaseObject)
        {
            System.Data.DataTable datatable = null;
            string sql = "Select * from [COVID].[Questionnaire] Where QuestionnaireId=-1";

            using (DbCommand readCommand = databaseObject.GetSqlStringCommand(sql))
            {
                DataSet dataset = databaseObject.ExecuteDataSet(readCommand);
                datatable = dataset.Tables[0];
            }

            return datatable;
        }

        /// <summary>
        /// Returns a QuestionnaireData DataTable, generated from the database table definition.
        /// </summary>
        /// <param name="databaseObject">Database object.</param>
        /// <returns>QuestionnaireData DataTable.</returns>
        private System.Data.DataTable GetDataTableQuestionnaireData(Database databaseObject)
        {
            System.Data.DataTable datatable = null;
            string sql = "Select * from [COVID].[QuestionnaireData] Where QuestionnaireDataId=-1";

            using (DbCommand readCommand = databaseObject.GetSqlStringCommand(sql))
            {
                DataSet dataset = databaseObject.ExecuteDataSet(readCommand);
                datatable = dataset.Tables[0];
            }

            return datatable;
        }

        /// <summary>
        /// Returns an IssuedQuestionnaire DataTable, generated from the database table definition.
        /// </summary>
        /// <param name="databaseObject">Database object.</param>
        /// <returns>Questionnaire DataTable.</returns>
        private System.Data.DataTable GetDataTableIssuedQuestionnaire(Database databaseObject)
        {
            System.Data.DataTable datatable = null;
            string sql = "Select * from [COVID].[IssuedQuestionnaire] Where IssuedQuestionnaireId=-1";

            using (DbCommand readCommand = databaseObject.GetSqlStringCommand(sql))
            {
                DataSet dataset = databaseObject.ExecuteDataSet(readCommand);
                datatable = dataset.Tables[0];
            }

            return datatable;
        }
    }
}