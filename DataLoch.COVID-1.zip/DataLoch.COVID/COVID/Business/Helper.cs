﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Globalization;
using Microsoft.Office.Interop.Excel;

namespace COVID.Business
{
    /// <summary>
    /// Contains helper methods.
    /// </summary>
    public static class Helper
    {
        public static void SetPropertyValueString(DataRow aDataRow, string aPropertyName, Range aCell)
        {
            string propertyValue = null;

            if (aCell.Value2 != null)
            {
                propertyValue = aCell.Value2.ToString();
            }

            SetPropertyValueString(aDataRow, aPropertyName, propertyValue);
        }

        public static void SetPropertyValueDateTime(DataRow aDataRow, string aPropertyName, Range aCell)
        {
            DateTime? propertyValue = null;

            if (aCell.Value2 != null)
            {
                Double serialDateValue;
                DateTime dateTimeValue;
                string dateTimeAsString = aCell.Value2.ToString();

                if (DateTime.TryParse(dateTimeAsString, out dateTimeValue))
                {
                    propertyValue = dateTimeValue;
                }
                else
                {
                    try
                    {
                        serialDateValue = Convert.ToDouble(aCell.Value2);
                        if (serialDateValue != 0)
                        {
                            dateTimeValue = DateTime.FromOADate(serialDateValue);
                            propertyValue = dateTimeValue;
                        }
                    }
                    catch (Exception ex)
                    {
                        // ignore exception 
                    }
                }
            }

            SetPropertyValueDateTime(aDataRow, aPropertyName, propertyValue);
        }

        public static void SetPropertyValueString(DataRow aDataRow, string aPropertyName, string propertyValue)
        {
            if (string.IsNullOrEmpty(propertyValue))
            {
                aDataRow[aPropertyName] = DBNull.Value;
            }
            else
            {
                aDataRow[aPropertyName] = propertyValue;
            }
        }

        public static void SetPropertyValueInt(DataRow aDataRow, string aPropertyName, int? propertyValue)
        {
            if (propertyValue.HasValue)
            {
                aDataRow[aPropertyName] = propertyValue;
            }
            else
            {
                aDataRow[aPropertyName] = DBNull.Value;
            }
        }

        public static void SetPropertyValueDouble(DataRow aDataRow, string aPropertyName, double? propertyValue)
        {
            if (propertyValue.HasValue)
            {
                aDataRow[aPropertyName] = propertyValue;
            }
            else
            {
                aDataRow[aPropertyName] = DBNull.Value;
            }
        }

        public static void SetPropertyValueDateTime(DataRow aDataRow, string aPropertyName, DateTime? propertyValue)
        {
            if (propertyValue.HasValue)
            {
                aDataRow[aPropertyName] = propertyValue;
            }
            else
            {
                aDataRow[aPropertyName] = DBNull.Value;
            }
        }

        public static string GetPropertyValueString(IDataReader aDataReader, string aPropertyName)
        {
            int propertyIndex = aDataReader.GetOrdinal(aPropertyName);

            if (aDataReader.IsDBNull(propertyIndex))
            {
                return null;
            }
            else
            {
                return aDataReader.GetString(propertyIndex);
            }
        }

        public static DateTime? GetPropertyValueDateTime(IDataReader aDataReader, string aPropertyName)
        {
            int propertyIndex = aDataReader.GetOrdinal(aPropertyName);

            if (aDataReader.IsDBNull(propertyIndex))
            {
                return null;
            }
            else
            {
                return aDataReader.GetDateTime(propertyIndex);
            }
        }

        public static TimeSpan? GetPropertyValueTimeSpan(IDataReader aDataReader, string aPropertyName)
        {
            int propertyIndex = aDataReader.GetOrdinal(aPropertyName);

            if (aDataReader.IsDBNull(propertyIndex))
            {
                return null;
            }
            else
            {
                return (TimeSpan)aDataReader.GetValue(propertyIndex);
            }
        }

        public static int? GetPropertyValueInt(IDataReader aDataReader, string aPropertyName)
        {
            int propertyIndex = aDataReader.GetOrdinal(aPropertyName);

            if (aDataReader.IsDBNull(propertyIndex))
            {
                return null;
            }
            else
            {
                return aDataReader.GetInt32(propertyIndex);
            }
        }

        public static double? GetPropertyValueDouble(IDataReader aDataReader, string aPropertyName)
        {
            int propertyIndex = aDataReader.GetOrdinal(aPropertyName);

            if (aDataReader.IsDBNull(propertyIndex))
            {
                return null;
            }
            else
            {
                return aDataReader.GetDouble(propertyIndex);
            }
        }

        public static decimal? GetPropertyValueDecimal(IDataReader aDataReader, string aPropertyName)
        {
            int propertyIndex = aDataReader.GetOrdinal(aPropertyName);

            if (aDataReader.IsDBNull(propertyIndex))
            {
                return null;
            }
            else
            {
                return aDataReader.GetDecimal(propertyIndex);
            }
        }

        public static int? GetPropertyValueInt(DataRow aDataRow, string aPropertyName)
        {

            if (aDataRow.IsNull(aPropertyName))
            {
                return null;
            }
            else
            {
                return Convert.ToInt32(aDataRow[aPropertyName]);
            }
        }

        public static DateTime? GetPropertyValueDateTime(DataRow aDataRow, string aPropertyName)
        {
            if (aDataRow.IsNull(aPropertyName))
            {
                return null;
            }
            else
            {
                return Convert.ToDateTime(aDataRow[aPropertyName]);
            }
        }

        public static string GetPropertyValueString(DataRow aDataRow, string aPropertyName)
        {
            if (aDataRow.IsNull(aPropertyName))
            {
                return null;
            }
            else
            {
                return Convert.ToString(aDataRow[aPropertyName]);
            }
        }

        /// <summary>
        /// Returns a Type map, used to map Types to their equivalent DbType.        
        /// </summary>        
        /// <returns>Type map.</returns>
        public static Dictionary<Type, DbType> GetTypeMap()
        {
            Dictionary<Type, DbType> typeMap = new Dictionary<Type, DbType>();

            typeMap[typeof(byte)] = DbType.Byte;
            typeMap[typeof(sbyte)] = DbType.SByte;
            typeMap[typeof(short)] = DbType.Int16;
            typeMap[typeof(ushort)] = DbType.UInt16;
            typeMap[typeof(int)] = DbType.Int32;

            typeMap[typeof(uint)] = DbType.UInt32;
            typeMap[typeof(long)] = DbType.Int64;
            typeMap[typeof(ulong)] = DbType.UInt64;
            typeMap[typeof(float)] = DbType.Single;
            typeMap[typeof(double)] = DbType.Double;

            typeMap[typeof(decimal)] = DbType.Decimal;
            typeMap[typeof(bool)] = DbType.Boolean;
            typeMap[typeof(string)] = DbType.String;
            typeMap[typeof(char)] = DbType.StringFixedLength;
            typeMap[typeof(Guid)] = DbType.Guid;

            typeMap[typeof(DateTime)] = DbType.DateTime;
            typeMap[typeof(DateTimeOffset)] = DbType.DateTimeOffset;
            typeMap[typeof(byte[])] = DbType.Binary;
            typeMap[typeof(byte?)] = DbType.Byte;
            typeMap[typeof(sbyte?)] = DbType.SByte;

            typeMap[typeof(short?)] = DbType.Int16;
            typeMap[typeof(ushort?)] = DbType.UInt16;
            typeMap[typeof(int?)] = DbType.Int32;
            typeMap[typeof(uint?)] = DbType.UInt32;
            typeMap[typeof(long?)] = DbType.Int64;

            typeMap[typeof(ulong?)] = DbType.UInt64;
            typeMap[typeof(float?)] = DbType.Single;
            typeMap[typeof(double?)] = DbType.Double;
            typeMap[typeof(decimal?)] = DbType.Decimal;
            typeMap[typeof(bool?)] = DbType.Boolean;

            typeMap[typeof(char?)] = DbType.StringFixedLength;
            typeMap[typeof(Guid?)] = DbType.Guid;
            typeMap[typeof(DateTime?)] = DbType.DateTime;
            typeMap[typeof(DateTimeOffset?)] = DbType.DateTimeOffset;

            return typeMap;
        }
    }
}