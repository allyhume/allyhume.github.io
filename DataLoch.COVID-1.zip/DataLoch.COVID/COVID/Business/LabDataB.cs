﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System.Data;
using System.Data.Common;
using COVID.Entities;
using COVID.Common;

namespace COVID.Business
{
    /// <summary>
    /// Provides methods to load and manipulate COVID related data.
    /// </summary>
    public class LabDataB
    {
        private Dictionary<Type, DbType> _typeMap;

        /// <summary>
        /// Constructor.
        /// </summary>
        public LabDataB()
        {
            _typeMap = Helper.GetTypeMap();
        }        

        /// <summary>
        /// Deletes all records from Lab table.
        /// </summary>
        public void DeleteLabData()
        {
            Database databaseObject = DatabaseFactory.CreateDatabase();
            string sql = "Delete From [COVID].[COVID_ILABS_DATA_V]";

            using (DbCommand cmd = databaseObject.GetSqlStringCommand(sql))
            {
                databaseObject.ExecuteNonQuery(cmd);
            }
        }

        /// <summary>
        /// Loads Lab data from the source (Oracle) database into the target database.
        /// </summary>        
        public void LoadLabData()
        {
            Database databaseObject = DatabaseFactory.CreateDatabase();

            ConfigParamB configParamB = new ConfigParamB();
            ConfigParam configParam = configParamB.Get(Constants.Config_Param_iLab_Select_Statement);

            // retrieve Lab records from source database
            //
            Database databaseSource = DatabaseFactory.CreateDatabase("COVIDOracle");           

            using (DbCommand cmd = databaseSource.GetSqlStringCommand(configParam.ParamValue))
            {
                using (IDataReader dataReader = databaseSource.ExecuteReader(cmd))
                {
                    while (dataReader.Read())
                    {
                        // add new Admission record to target database
                        Insert(databaseObject, "COVID", "COVID_ILABS_DATA_V", dataReader);
                    }
                }
            }
        }

        /// <summary>
        /// Sets flag to indicate that Lab data has been loaded successfully.
        /// </summary>
        public void LabDataLoaded()
        {
            Database databaseObject = DatabaseFactory.CreateDatabase();

            string storedProcedureName = "[DataLoch].[NewCovidLabsDataReceived]";

            using (DbCommand cmd = databaseObject.GetStoredProcCommand(storedProcedureName))
            {
                cmd.CommandTimeout = 7200;   // 2 hours = 60 * 60 * 2 = 7200 seconds
                databaseObject.ExecuteNonQuery(cmd);
            }           
        }

        /// <summary>
        /// Inserts a new record into the target table.
        /// </summary>
        /// <param name="databaseObject">Database object.</param>
        /// <param name="schemaName">Schema name.</param>
        /// <param name="tableName">Table name.</param>
        /// <param name="dataReader">Details of new record to be inserted.</param>
        /// <param name="excludedColumnList">List of excluded column names.</param>
        private void Insert(Database databaseObject, string schemaName, string tableName, IDataReader dataReader)
        {
            string queryString = "Insert Into [" + schemaName + "].[" + tableName + "] (";

            string columnList = string.Empty;
            string parameterList = string.Empty;
            string fieldName;

            for (int fieldIndex = 0; fieldIndex < dataReader.FieldCount; fieldIndex++)
            {
                fieldName = dataReader.GetName(fieldIndex);

                if (columnList != string.Empty)
                {
                    columnList += ", ";
                }

                columnList += fieldName;

                if (parameterList != string.Empty)
                {
                    parameterList += ", ";
                }

                parameterList += "@" + fieldName;
            }

            queryString += columnList + ") Values (" + parameterList + ")";

            DbCommand insertCommand = databaseObject.GetSqlStringCommand(queryString);

            for (int fieldIndex = 0; fieldIndex < dataReader.FieldCount; fieldIndex++)
            {
                fieldName = dataReader.GetName(fieldIndex);
                databaseObject.AddInParameter(insertCommand, fieldName, _typeMap[dataReader.GetFieldType(fieldIndex)], dataReader[fieldName]);
            }

            databaseObject.ExecuteNonQuery(insertCommand);
        }
    }
}
