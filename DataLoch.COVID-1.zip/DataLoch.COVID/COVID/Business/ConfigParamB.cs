﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System.Data;
using System.Data.Common;
using COVID.Entities;

namespace COVID.Business
{
    /// <summary>
    /// Provides methods to manage Configuration Parameters.
    /// </summary>
    public class ConfigParamB
    {        
        /// <summary>
        /// Constructor.
        /// </summary>
        public ConfigParamB()
        {            
        }

        /// <summary>
        /// Returns the configuration parameter with the given name.
        /// </summary>
        /// <param name="paramName">Parameter name.</param>
        /// <returns>Matching configuration parameter.</returns>
        public ConfigParam Get(string paramName)
        {
            ConfigParam configParam = null;
            
            Database databaseObject = DatabaseFactory.CreateDatabase();

            string sql = "Select ";
            sql += "cnfg.ParamName, ";
            sql += "cnfg.ParamValue ";
            sql += "From [COVID].[ConfigParam] cnfg ";
            sql += "Where cnfg.ParamName = @ParamName";
         
            using (DbCommand cmd = databaseObject.GetSqlStringCommand(sql))
            {                
                databaseObject.AddInParameter(cmd, "ParamName", DbType.String, paramName);

                using (IDataReader dataReader = databaseObject.ExecuteReader(cmd))
                {
                    if (dataReader.Read())
                    {
                        configParam = new ConfigParam();
                        configParam.ParamName = Helper.GetPropertyValueString(dataReader, "ParamName");
                        configParam.ParamValue = Helper.GetPropertyValueString(dataReader, "ParamValue");
                    }
                }
            }

            return configParam;
        } 
    }
}
