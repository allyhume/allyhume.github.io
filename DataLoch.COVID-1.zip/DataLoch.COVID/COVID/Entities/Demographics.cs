﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Entities
{
    public class Demographics
    {        
        public virtual string CHI { get; set; }
        public virtual string UHPI { get; set; }
        public virtual DateTime? DateOfBirth { get; set; }        
        public virtual string Sex { get; set; }
        public virtual DateTime? EpisodeStart { get; set; }
        public virtual DateTime? EpisodeEnd { get; set; }                 
    }    
}
