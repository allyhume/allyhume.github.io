﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Entities
{
    public class Task
    {
        public virtual int? TaskId { get; set; }
        public virtual string TaskDesc { get; set; }
    }    
}
