﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Entities
{
    public class ConfigParam
    {
        public virtual string ParamName { get; set; }
        public virtual string ParamValue { get; set; }
    }    
}
