﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COVID.Common
{
    /// <summary>
    /// Holds constant declarations.
    /// </summary>
    public class Constants
    {
        public const string DateTimeFormat = "dd MMM yyyy HH:mm:ss";

        public const string Task_iLab_COVID_Refresh = "iLab COVID Refresh";
        public const string Task_Generate_Questionnaires = "Generate Questionnaires";
        public const string Task_Load_Questionnaires = "Load Questionnaires";

        public const string Config_Param_iLab_Select_Statement = "Oracle iLabs SQL Select Statement";
    }
}
