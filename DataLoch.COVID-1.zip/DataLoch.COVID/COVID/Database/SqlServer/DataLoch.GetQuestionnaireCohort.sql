IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[DataLoch].[GetQuestionnaireCohort]') AND type in (N'P', N'PC'))
DROP PROCEDURE [DataLoch].[GetQuestionnaireCohort]
GO

SET ANSI_NULLS OFF
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [DataLoch].[GetQuestionnaireCohort]
AS

BEGIN

	SET NOCOUNT ON;

	Select dmg.UHPI, dmg.CHI, dmg.DateOfBirth, dmg.Sex, dmg.EpisodeStart, dmg.EpisodeEnd
	From [DataLoch].[Demographics] dmg
	Left Join [COVID].[IssuedQuestionnaire] issd On (dmg.CHI = issd.CHI Or dmg.UHPI = issd.UHPI) And ((dmg.EpisodeStart Is Null And issd.EpisodeStart Is Null) Or dmg.EpisodeStart = issd.EpisodeStart)
	Where dmg.AnyPositiveTest = 'Y'
	And dmg.OutcomeCompleted = 'Y'
	And ((dmg.CHI Is Not Null And dmg.CHI != '')
	Or (dmg.UHPI Is Not Null And dmg.UHPI != ''))
	And issd.IssuedQuestionnaireId Is Null

	SET NOCOUNT OFF;	
	
	RETURN
END
GO