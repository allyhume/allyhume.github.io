﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Threading.Tasks;
using System.Timers;
using COVID.Business;
using COVID.Entities;
using COVID.Common;

namespace COVID
{    
    /// <summary>
    /// Main entry point to the program.
    /// </summary>
    class Program
    {
        private static Timer timer;               
        
        // use Lock when retrieving next task from database
        private static readonly object lockerObj = new object();                

        /// <summary>
        /// Main entry point for the application.
        /// </summary>
        /// <param name="args">Command line arguments.</param>
        static int Main(string[] args)
        {
            int exitCode = 0; // success            

            try
            {               
                SetTimer();

                Console.WriteLine("\nPress the Enter key to exit the application...\n");
                Console.WriteLine("The application started at {0:HH:mm:ss.fff}", DateTime.Now);                

                Console.ReadLine();
                timer.Stop();
                timer.Dispose();

                Console.WriteLine("Terminating the application...");                
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error occurred:");
                Console.WriteLine(ex.ToString());
                exitCode = -1; // error
            }            

            return exitCode;
        }

        private static void SetTimer()
        {
            string timerIntervalAsString = ConfigurationManager.AppSettings["TimerInterval"];
            int timerInterval;
            if (!Int32.TryParse(timerIntervalAsString, out timerInterval))
            {
                // default to 1 minute
                timerInterval = 1000 * 60;
            }

            timer = new System.Timers.Timer(timerInterval);
            // Hook up the Elapsed event for the timer. 
            timer.Elapsed += OnTimedEvent;
            timer.AutoReset = true;
            timer.Enabled = true;
        }

        private static void OnTimedEvent(Object source, ElapsedEventArgs e)
        {
            try
            {
                COVID.Entities.Task task = null;

                lock (lockerObj)
                {
                    TaskB taskB = new TaskB();
                    task = taskB.GetNextTask();

                    if (task != null &&
                        task.TaskId.HasValue &&
                        !string.IsNullOrEmpty(task.TaskDesc))
                    {
                        bool success = taskB.StartTask(task.TaskId);
                        if (!success)
                        {
                            // failed to flag Task as Started, abandon processing of Task
                            task = null;
                        }
                    }
                }

                if (task != null &&
                        task.TaskId.HasValue &&
                        !string.IsNullOrEmpty(task.TaskDesc))
                {
                    switch (task.TaskDesc)
                    {
                        case Constants.Task_iLab_COVID_Refresh:
                            LoadLabRecords(task.TaskId);
                            break;
                        case Constants.Task_Generate_Questionnaires:
                            GeneratesQuestionnaires(task.TaskId);
                            break;
                        case Constants.Task_Load_Questionnaires:
                            LoadQuestionnaires(task.TaskId);
                            break;
                        default:
                            TaskDescNotRecognised(task.TaskId);
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine();
                Console.WriteLine(ex.ToString());
                Console.WriteLine();
            }
        }

        /// <summary>  
        /// Loads Lab records from the source Oracle database.                      
        /// </summary>
        /// <param name="taskId">Task Id.</param>               
        private static void LoadLabRecords(int? taskId)
        {
            TaskB taskB = new TaskB();
            string completionStatus = string.Empty;

            try
            { 
                LabDataB labDataB = new LabDataB();                               
                
                Console.WriteLine();
                string message = string.Format("Task Id '{0}'. Started deleting existing Lab records at {1}", taskId.Value, DateTime.Now.ToString("dd MMM yyyy HH:mm:ss"));
                Console.WriteLine(message);

                labDataB.DeleteLabData();

                message = string.Format("Task Id '{0}'. Finished deleting existing Lab records at {1}", taskId.Value, DateTime.Now.ToString("dd MMM yyyy HH:mm:ss"));
                Console.WriteLine(message);

                message = string.Format("Task Id '{0}'. Started loading Lab records at {1}", taskId.Value, DateTime.Now.ToString("dd MMM yyyy HH:mm:ss"));
                Console.WriteLine(message);

                labDataB.LoadLabData();

                message = string.Format("Task Id '{0}'. Finished loading Lab records at {1}", taskId.Value, DateTime.Now.ToString("dd MMM yyyy HH:mm:ss"));
                Console.WriteLine(message);

                message = string.Format("Task Id '{0}'. Started setting 'Lab Data Loaded' flag at {1}", taskId.Value, DateTime.Now.ToString("dd MMM yyyy HH:mm:ss"));
                Console.WriteLine(message);

                labDataB.LabDataLoaded();

                message = string.Format("Task Id '{0}'. Finished setting 'Lab Data Loaded' flag at {1}", taskId.Value, DateTime.Now.ToString("dd MMM yyyy HH:mm:ss"));
                Console.WriteLine(message);
                Console.WriteLine();

                completionStatus = "Success";                                                 
            }
            catch (Exception ex)
            {
                completionStatus = string.Format("Failure '{0}'.", ex.Message);               
                Console.WriteLine(ex.ToString());               
            }
            finally
            {
                taskB.CompleteTask(taskId, completionStatus);
            }
        }

        /// <summary>  
        /// Generates a Questionnaire (excel spreadsheet) for each COVID positive patient.               
        /// </summary>
        /// <param name="taskId">Task Id.</param>               
        private static void GeneratesQuestionnaires(int? taskId)
        {
            TaskB taskB = new TaskB();
            string completionStatus = string.Empty;

            try
            {
                QuestionnaireB questionnaireB = new QuestionnaireB();

                Console.WriteLine();
                string message = string.Format("Task Id '{0}'. Started generating questionnaires at {1}", taskId.Value, DateTime.Now.ToString("dd MMM yyyy HH:mm:ss"));
                Console.WriteLine(message);

                string taskSummaryDetails;
                bool success = questionnaireB.GenerateQuestionnaires(out taskSummaryDetails);

                message = string.Format("Task Id '{0}'. Finished generating questionnaires at {1}", taskId.Value, DateTime.Now.ToString("dd MMM yyyy HH:mm:ss"));
                Console.WriteLine(message);
                Console.WriteLine();

                if (success)
                {
                    completionStatus = string.Format("Success: {0}", taskSummaryDetails);
                }
                else
                {
                    completionStatus = string.Format("Failure: {0}", taskSummaryDetails);
                }
            }
            catch (Exception ex)
            {
                completionStatus = string.Format("Failure: '{0}'.", ex.Message);
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                taskB.CompleteTask(taskId, completionStatus);
            }
        }

        /// <summary>  
        /// Extracts data from completed Questionnaires (each completed questionnaire is an excel spreadsheet)
        /// and loads the data into the database.       
        /// </summary>
        /// <param name="taskId">Task Id.</param>               
        private static void LoadQuestionnaires(int? taskId)
        {
            TaskB taskB = new TaskB();
            string completionStatus = string.Empty;

            try
            {
                QuestionnaireB questionnaireB = new QuestionnaireB();

                Console.WriteLine();
                string message = string.Format("Task Id '{0}'. Started loading completed questionnaires at {1}", taskId.Value, DateTime.Now.ToString("dd MMM yyyy HH:mm:ss"));
                Console.WriteLine(message);

                string taskSummaryDetails;
                bool success = questionnaireB.LoadCompletedQuestionnaires(out taskSummaryDetails);
               
                message = string.Format("Task Id '{0}'. Finished loading completed questionnaires at {1}", taskId.Value, DateTime.Now.ToString("dd MMM yyyy HH:mm:ss"));
                Console.WriteLine(message);                
                Console.WriteLine();

                if (success)
                {
                    completionStatus = string.Format("Success: {0}", taskSummaryDetails);
                }
                else
                {
                    completionStatus = string.Format("Failure: {0}", taskSummaryDetails);
                }
            }
            catch (Exception ex)
            {
                completionStatus = string.Format("Failure '{0}'.", ex.Message);
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                taskB.CompleteTask(taskId, completionStatus);
            }
        }

        /// <summary>  
        /// Where the Task Description for a given Task is not recognised, the Task is completed
        /// with a status of 'Failure'.      
        /// </summary>
        /// <param name="taskId">Task Id.</param>               
        private static void TaskDescNotRecognised(int? taskId)
        {
            TaskB taskB = new TaskB();
            string completionStatus = "Failure: Task Description not recognised.";           
            taskB.CompleteTask(taskId, completionStatus);           
        }
    }    
}
